# Amazon_task
Task1
